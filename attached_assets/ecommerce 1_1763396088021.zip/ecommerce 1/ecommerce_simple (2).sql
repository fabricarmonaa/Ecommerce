-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-11-2025 a las 20:04:05
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ecommerce_simple`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `category` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `featured` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image_url`, `stock`, `category`, `created_at`, `featured`) VALUES
(7, 'dwa', 'dawfd', 32.00, '/uploads/img_16791ef78ef200f6.png', 32, 'ewww', '2025-10-08 20:56:33', 0),
(8, 'AAA', 'EWQFD', 22.00, '/uploads/img_b67f697ff3051c93.png', 32, 'RERERR', '2025-10-08 21:14:30', 0),
(9, 'w', '2', 2.00, '/uploads/img_1687174f02be901b.png', 2, '2', '2025-10-11 23:44:33', 0),
(10, 'cac', '2', 22.00, '/uploads/img_4b3191c4df7b5642.png', 2, '2', '2025-10-12 00:28:30', 1),
(11, '5423', '32', 342.00, '/uploads/img_7c11539d6c0d0002.png', 32, '32', '2025-10-12 00:37:25', 1),
(12, 'mtcosido', '543', 2.00, '/uploads/img_c72319b7b161d47a.png', 2, '3', '2025-10-12 01:27:59', 1),
(13, '2', 'gv', 2.00, '/uploads/img_e08d3876e271be12.png', 32, '44', '2025-10-12 01:36:35', 1),
(14, 'wsd', '32', 23.00, '/uploads/img_202ed7a1e1982dee.png', 32, '32', '2025-10-12 01:42:40', 1),
(15, '3', '3', 3.00, '/uploads/img_486191654e3288b3.png', 3, '3', '2025-10-12 01:47:34', 0),
(16, 'w', '2', 2.00, '/uploads/img_8ff0f03d28bc11bd.png', 2, '2', '2025-11-12 18:48:32', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `url` varchar(500) NOT NULL,
  `position` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `url`, `position`, `created_at`) VALUES
(1, 8, '/uploads/img_b67f697ff3051c93.png', 0, '2025-10-08 21:14:30'),
(2, 8, '/uploads/img_59595d9c6fc7a267.jpg', 1, '2025-10-08 21:14:30'),
(3, 8, '/uploads/img_7c67b04a40c1a0a4.jpg', 2, '2025-10-08 21:14:30'),
(4, 8, '/uploads/img_0835d47a5a2adb2f.jpg', 3, '2025-10-08 21:14:30'),
(5, 8, '/uploads/img_89c176a7e6294850.jpg', 4, '2025-10-08 21:14:30'),
(6, 16, '/uploads/img_8ff0f03d28bc11bd.png', 0, '2025-11-12 18:48:32'),
(7, 16, '/uploads/img_382d1b77faea8a23.jpg', 1, '2025-11-12 18:48:32'),
(8, 16, '/uploads/img_577a0f71c4ce71d7.jpg', 2, '2025-11-12 18:48:32'),
(9, 16, '/uploads/img_1cacdfd231dd3f0d.jpg', 3, '2025-11-12 18:48:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','user') DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `role`, `created_at`) VALUES
(1, 'admin', '$2b$12$iL9JduoYGoFXOadIyDGcoelVy.BgeIslywkryWoIiB6RE68GZKC0C', 'admin', '2025-10-08 19:39:01');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_products_featured` (`featured`),
  ADD KEY `idx_products_name` (`name`);

--
-- Indices de la tabla `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_product_images_product` (`product_id`,`position`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `fk_product_images_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
