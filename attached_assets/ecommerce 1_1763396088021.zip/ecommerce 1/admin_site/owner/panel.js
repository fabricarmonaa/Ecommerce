// ===== estado de sesión =====
let csrf = null;
let sid  = null;
let imagesUploaded = [];

function withCred(opts={}) {
  const headers = { ...(opts.headers||{}) };
  if (sid) headers['x-session-id'] = sid;
  return { credentials: 'same-origin', ...opts, headers };
}

async function fetchMe() {
  const r = await fetch('/api/admin/me', withCred());
  if (!r.ok) return false;
  const j = await r.json().catch(()=>({}));
  csrf = j.csrf;
  return !!csrf;
}

// ===== listado admin =====
async function load() {
  const r = await fetch('/api/products?limit=100&offset=0', withCred({ headers:{'Accept':'application/json'} }));
  const j = await r.json().catch(()=>({}));
  const items = Array.isArray(j) ? j : (j.items || []); // <- tolerante a ambos formatos
  const box = document.getElementById('list');
  if (!items.length) { box.innerHTML = '<p>No hay productos.</p>'; return; }
  box.innerHTML = items.map(p => `
    <div class="card" style="padding:12px;margin-bottom:8px">
      <div style="display:flex; gap:10px; align-items:center">
        <img src="${p.image_url||''}" alt="" style="width:70px;height:70px;object-fit:cover;border-radius:8px;border:1px solid #222"/>
        <div style="flex:1">
          <b>#${p.id}</b> ${p.name} — <b>$${p.price}</b><br/>
          <small>${p.category||'-'} | stock ${p.stock||0}</small>
        </div>
        <button class="btn ghost" data-id="${p.id}" data-action="del">Borrar</button>
      </div>
    </div>
  `).join('');

  box.querySelectorAll('[data-action="del"]').forEach(btn=>{
    btn.onclick = async () => {
      const id = Number(btn.dataset.id);
      if (!confirm('¿Eliminar producto #' + id + '?')) return;
      const rr = await fetch('/api/admin/product/'+id, withCred({
        method:'DELETE',
        headers: { 'x-csrf-token': csrf }
      }));
      if (!rr.ok) { alert('No se pudo eliminar'); return; }
      load();
    };
  });
}

// ====== SUBIR IMÁGENES (hasta 5) ======
// === helpers de sesión/tokens ===
async function ensureTokens() {
  try {
    if (!sid)  sid  = sessionStorage.getItem('sid');
    if (!csrf) csrf = sessionStorage.getItem('csrf');
  } catch {}
  if (!csrf && sid) {
    const r = await fetch('/api/admin/me', { headers: { 'x-session-id': sid } });
    if (r.ok) {
      const me = await r.json().catch(()=>({}));
      if (me?.csrf) { csrf = me.csrf; sessionStorage.setItem('csrf', csrf); }
    }
  }
  return Boolean(sid && csrf);
}

// === subir imágenes (hasta 5), robusto y con diagnósticos ===
// === subir imágenes (hasta 5), robusto y sin usar 'r' en el catch ===
async function uploadFiles(e) {
  e?.preventDefault?.();

  // tokens
  const okTokens = await ensureTokens();
  if (!okTokens) {
    alert('Tu sesión expiró. Volvé a iniciar sesión.');
    window.location.href = '/owner/login';
    return;
  }

  // archivos
  const input = document.getElementById('files');
  const files = Array.from(input?.files || []);
  if (!files.length) { alert('Elegí imágenes'); return; }

  // máximo 5 total
  const toSend = files.slice(0, Math.max(0, 5 - imagesUploaded.length));

  for (const f of toSend) {
    try {
      const fd = new FormData();
      // el backend acepta 'image' o 'file' (tenemos ambos por compatibilidad)
      fd.append('image', f, f.name);
      fd.append('file', f, f.name);

      const resp = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: {
          'x-session-id': sid,
          'x-csrf-token': csrf,
          'Accept': 'application/json'
        },
        body: fd,
        credentials: 'same-origin'
      });

      if (!resp.ok) {
        // tratá de extraer el mensaje real del server
        let msg = `HTTP ${resp.status}`;
        try {
          const text = await resp.text();
          try { msg = JSON.parse(text).error || msg; } catch { if (text) msg = text; }
        } catch {}
        alert('Upload falló: ' + msg);
        continue;
      }

      const j = await resp.json().catch(()=> ({}));
      if (j?.url) {
        imagesUploaded.push(j.url);
      } else {
        alert('Upload falló: respuesta inválida del servidor.');
      }
    } catch (err) {
      // ⚠️ IMPORTANTE: no referenciar 'resp'/'r' acá; solo 'err'
      alert('Upload falló (cliente): ' + (err?.message || String(err)));
    }
  }

  // Previews y set principal
  const prev = document.getElementById('preview');
  if (prev) prev.innerHTML = imagesUploaded.map(u => `<img src="${u}" class="thumb" />`).join('');
  const main = document.getElementById('image_url');
  if (main && !main.value && imagesUploaded.length) main.value = imagesUploaded[0];
}




// ====== CREAR ======
async function create(e) {
  e?.preventDefault?.();

  const ok = await ensureTokens();
  if (!ok) { alert('Tu sesión expiró. Iniciá sesión otra vez.'); window.location.href='/owner/login'; return; }

  const body = {
    name: document.getElementById('name').value.trim(),
    price: Number(document.getElementById('price').value || 0),
    image_url: document.getElementById('image_url').value.trim(),
    stock: Number(document.getElementById('stock').value || 0),
    category: document.getElementById('category').value.trim(),
    description: document.getElementById('description').value.trim(),
    featured: document.getElementById('featured').checked ? 1 : 0
  };

  if (!body.name) return alert('Falta nombre');
  if (!body.price) return alert('Falta precio');
  if (!body.image_url) return alert('Subí al menos una imagen');

  const btn = document.getElementById('btn-create') || document.querySelector('#btn-create, button#create');
  if (btn) { btn.disabled = true; btn.textContent = 'Creando...'; }

  try {
    const r = await fetch('/api/admin/product', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-session-id': sid,
        'x-csrf-token': csrf,
        'Accept': 'application/json'
      },
      body: JSON.stringify(body)
    });
    const j = await r.json().catch(()=>({}));
    if (!r.ok) { alert('No se pudo crear: ' + (j.error || r.status)); return; }

    const productId = j.id;

    // Si subiste imágenes extra, guardá la galería (opcional)
   if (imagesUploaded.length > 1) {
  await fetch('/api/admin/product-images', {
    method:'POST',
    headers: {
      'Content-Type':'application/json',
      'x-session-id': sid,
      'x-csrf-token': csrf
    },
    body: JSON.stringify({ productId, images: imagesUploaded.slice(0,5) })
  });
}


    // Reset UI y recargar listado
    imagesUploaded = [];
    ['name','price','stock','category','description','image_url'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = '';
    });
    const f = document.getElementById('files'); if (f) f.value = '';
    const p = document.getElementById('preview'); if (p) p.innerHTML = '';
    const feat = document.getElementById('featured'); if (feat) feat.checked = false;

    await load();
    alert('Producto creado (#' + productId + ').');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Crear'; }
  }
}

// ====== init ======
document.getElementById('btn-upload')?.addEventListener('click', uploadFiles);
document.getElementById('btn-create')?.addEventListener('click', create);

(async () => {
  try { sid = sessionStorage.getItem('sid') || null; } catch {}
  const ok = await fetchMe();
  if (!ok) { window.location.href = '/owner/login'; return; }
  await load();
})();
