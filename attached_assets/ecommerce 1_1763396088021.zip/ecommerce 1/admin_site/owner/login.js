let sid = null;
let csrf = null;

function withCred(opts={}){
  const headers = { ...(opts.headers||{}) };
  if (sid) headers['x-session-id'] = sid;
  return { credentials: 'same-origin', ...opts, headers };
}

async function fetchMe(){
  const r = await fetch('/api/admin/me', withCred());
  if (!r.ok) return false;
  const j = await r.json();
  csrf = j.csrf;
  return true;
}

document.getElementById('btn-login').onclick = async () => {
  const username = document.getElementById('u').value.trim();
  const password = document.getElementById('p').value;
  const msg = document.getElementById('auth-msg');

  try {
    const r = await fetch('/api/admin/login', withCred({
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ username, password })
    }));
    const j = await r.json().catch(()=>({}));
    if (!r.ok) { msg.textContent = j.error || 'Credenciales inválidas'; return; }

    sid = j.sid || null;
    try { sessionStorage.setItem('sid', sid); sessionStorage.setItem('csrf', j.csrf);} catch {}
    const ok = await fetchMe();
    if (!ok) { msg.textContent = 'No se pudo verificar la sesión'; return; }

    // Ir al panel
    window.location.href = '/owner/panel.html';
  } catch (e) {
    msg.textContent = 'Error de red';
  }
};
