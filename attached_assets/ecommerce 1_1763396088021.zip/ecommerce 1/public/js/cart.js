import { formatCurrency, escapeHtml } from './utils.js';

const STORAGE_KEY = 'cart.v1';

export class Cart {
  constructor() {
    this.items = this._load();
  }

  _load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  _save() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.items));
    document.dispatchEvent(new CustomEvent('cart:updated', { detail: this.items }));
  }

  getTotal() {
    return this.items.reduce((acc, it) => acc + (Number(it.price) * Number(it.qty)), 0);
  }

  addItem(product, qty = 1) {
    const id = String(product.id);
    const found = this.items.find(i => i.id === id);
    if (found) {
      found.qty += qty;
    } else {
      this.items.push({
        id,
        name: String(product.name || ''),
        price: Number(product.price || 0),
        qty: Number(qty || 1)
      });
    }
    this._save();
  }

  setQty(id, qty) {
    const it = this.items.find(i => i.id === String(id));
    if (!it) return;
    it.qty = Math.max(1, Number(qty || 1));
    this._save();
  }

  remove(id) {
    this.items = this.items.filter(i => i.id !== String(id));
    this._save();
  }

  clear() {
    this.items = [];
    this._save();
  }

  toWhatsAppMessage() {
    const lines = this.items.map(i => `- ${i.qty} ${i.name}`);
    const total = this.getTotal();
    const parts = [
      'Hola, estoy interesado en comprar:',
      ...lines,
      `Total del carrito: $ ${total}`
    ];
    return parts.join('\n');
  }
}

// UI helpers
export function renderCart(container, cart) {
  if (!container) return;
  if (!cart.items.length) {
    container.innerHTML = `<p>Tu carrito está vacío.</p>`;
    updateTotals();
    return;
  }

  container.innerHTML = cart.items.map(i => `
    <div class="cart-row">
      <div class="cart-name" title="${escapeHtml(i.name)}">${escapeHtml(i.name)}</div>
      <div class="cart-qty">
        <input type="number" min="1" value="${i.qty}" data-id="${i.id}" />
      </div>
      <div class="cart-price">${formatCurrency(i.price * i.qty)}</div>
      <button class="cart-remove" data-id="${i.id}" aria-label="Quitar ${escapeHtml(i.name)}">×</button>
    </div>
  `).join('');

  // Eventos cantidad
  container.querySelectorAll('input[type="number"]').forEach(inp => {
    inp.addEventListener('change', () => {
      cart.setQty(inp.dataset.id, Number(inp.value));
      renderCart(container, cart);
      updateTotals();
    });
  });

  // Eventos quitar
  container.querySelectorAll('.cart-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      cart.remove(btn.dataset.id);
      renderCart(container, cart);
      updateTotals();
    });
  });

  updateTotals();
}

export function updateTotals() {
  const totalEl = document.getElementById('cart-total');
  const countEl = document.getElementById('cart-count');
  const phoneEl = document.getElementById('wa-phone');
  const btn = document.getElementById('btn-wa');

  const items = currentCart.items;
  const total = currentCart.getTotal();
  if (totalEl) totalEl.textContent = formatCurrency(total);
  if (countEl) countEl.textContent = String(items.reduce((a, i) => a + i.qty, 0));

  if (btn) {
    btn.onclick = () => {
      let phone = (phoneEl?.value || '').replace(/[^\d]/g, '');
      if (!phone) {
        // fallback a .env via inyección en el HTML (ver index.html)
        phone = (window.__ENV__?.WHATSAPP_PHONE || '').replace(/[^\d]/g, '');
      }
      if (!phone) {
        alert('Ingresá un número de WhatsApp (con código de país y sin +).');
        phoneEl?.focus?.();
        return;
      }
      const msg = currentCart.toWhatsAppMessage();
      const url = `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
      window.open(url, '_blank');
    };
  }
}

// Cart singleton simple
export const currentCart = new Cart();
