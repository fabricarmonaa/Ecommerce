let csrf = null;
let sid  = null; // fallback cuando cookie no persiste
let imagesUploaded = [];
function withCred(opts = {}) {
  const headers = { ...(opts.headers || {}) };
  if (sid) headers['x-session-id'] = sid;
  return { credentials: 'same-origin', ...opts, headers };
}

function setLoggedInUI(on) {
  document.getElementById('btn-login').style.display  = on ? 'none' : 'inline-block';
  document.getElementById('btn-logout').style.display = on ? 'inline-block' : 'none';
}

function loadSidFromStorage() { try { sid = sessionStorage.getItem('sid') || null; } catch {} }
function saveSidToStorage(v)  { try { v ? sessionStorage.setItem('sid', v) : sessionStorage.removeItem('sid'); } catch {} }

async function tryFetchMeOnce() {
  try {
    const r = await fetch('/api/admin/me', withCred());
    if (!r.ok) { setLoggedInUI(false); csrf = null; return false; }
    const j = await r.json();
    csrf = j.csrf;
    setLoggedInUI(true);
    return true;
  } catch {
    setLoggedInUI(false);
    csrf = null;
    return false;
  }
}

async function login() {
  const username = document.getElementById('u').value;
  const password = document.getElementById('p').value;

  const r = await fetch('/api/admin/login', withCred({
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  }));

  const j = await r.json().catch(() => ({}));
  const msg = document.getElementById('auth-msg');

  if (!r.ok) {
    msg.textContent = j.error || 'Credenciales inválidas';
    setLoggedInUI(false);
    csrf = null;
    saveSidToStorage(null);
    sid = null;
    return;
  }

  msg.textContent = 'OK';
  sid = j.sid || null;       // <- guardamos el SID devuelto por el login
  saveSidToStorage(sid);

  await tryFetchMeOnce();    // obtiene csrf y ajusta UI
  await load();              // refresca listado
}

async function logout() {
  await fetch('/api/admin/logout', withCred({ method: 'POST' }));
  csrf = null;
  sid = null;
  saveSidToStorage(null);
  setLoggedInUI(false);
}

async function uploadFiles() {
  const input = document.getElementById('files');
  const files = Array.from(input.files || []);
  if (!files.length) { alert('Elegí imágenes'); return; }
  if (!csrf) { alert('Iniciá sesión primero'); return; }

  const toSend = files.slice(0, 5 - imagesUploaded.length); // límite 5
  if (!toSend.length) { alert('Ya tenés 5 imágenes cargadas'); return; }

  for (const f of toSend) {
    if (f.size > 5 * 1024 * 1024) { alert(`${f.name} supera 5 MB`); continue; }
    const fd = new FormData();
    fd.append('image', f);
    const r = await fetch('/api/admin/upload', withCred({
      method: 'POST',
      headers: { 'x-csrf-token': csrf },
      body: fd
    }));
    const j = await r.json().catch(()=>({}));
    if (r.ok && j.url) {
      imagesUploaded.push(j.url);
    } else {
      alert(`Error subiendo ${f.name}: ` + (j.error || r.status));
    }
  }

  // Completar imagen principal con la primera si no hay
  const main = document.getElementById('image_url');
  if (!main.value && imagesUploaded.length) main.value = imagesUploaded[0];

  // Preview
  const prev = document.getElementById('preview');
  prev.innerHTML = imagesUploaded.map(u =>
    `<img src="${u}" alt="preview" class="thumb" />`
  ).join('');
}

async function load() {
  const r = await fetch('/api/products', withCred());
  const data = await r.json().catch(() => ({ items: [] }));
  const items = Array.isArray(data) ? data : (data.items || []);
  const list = document.getElementById('list');
  list.innerHTML = items.map(p => `
    <div class="card" style="padding:10px">
      <b>#${p.id}</b> ${p.name} — $${p.price} ${p.featured ? '🌟' : ''}
      <div>
        <button data-id="${p.id}" class="edit">Editar</button>
        <button data-id="${p.id}" class="feat">${p.featured ? 'Quitar Destacado' : 'Marcar Destacado'}</button>
        <button data-id="${p.id}" class="del">Borrar</button>
      </div>
    </div>
  `).join('');

  // borrar
  list.querySelectorAll('.del').forEach(btn => {
    btn.onclick = async () => {
      if (!csrf) { alert('Iniciá sesión primero'); return; }
      if (!confirm('¿Borrar producto?')) return;
      const id = btn.dataset.id;
      const r = await fetch('/api/admin/product?id=' + id, withCred({
        method: 'DELETE', headers: { 'x-csrf-token': csrf }
      }));
      if (r.ok) load();
      else alert('Error al borrar');
    };
  });

  // editar nombre
  list.querySelectorAll('.edit').forEach(btn => {
    btn.onclick = async () => {
      if (!csrf) { alert('Iniciá sesión primero'); return; }
      const id = btn.dataset.id;
      const name = prompt('Nuevo nombre:'); if (!name) return;
      const r = await fetch('/api/admin/product?id=' + id, withCred({
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'x-csrf-token': csrf },
        body: JSON.stringify({ name })
      }));
      if (r.ok) load(); else alert('Error al editar');
    };
  });

  // destacado
  list.querySelectorAll('.feat').forEach(btn => {
    btn.onclick = async () => {
      if (!csrf) { alert('Iniciá sesión primero'); return; }
      const id = btn.dataset.id;
      const isOn = btn.textContent.includes('Quitar');
      const r = await fetch('/api/admin/product?id=' + id, withCred({
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'x-csrf-token': csrf },
        body: JSON.stringify({ featured: isOn ? 0 : 1 })
      }));
      if (r.ok) load(); else alert('Error al actualizar destacado');
    };
  });
}

async function create() {
  if (!csrf) { alert('Iniciá sesión primero'); return; }

  const main = document.getElementById('image_url').value;
  if (!main) { alert('Subí al menos una imagen'); return; }

  const body = {
    name: document.getElementById('name').value,
    price: Number(document.getElementById('price').value),
    image_url: main,
    stock: Number(document.getElementById('stock').value || 0),
    category: document.getElementById('category').value,
    description: document.getElementById('description').value,
    featured: document.getElementById('featured').checked ? 1 : 0
  };

  // 1) Crear producto
  const r = await fetch('/api/admin/product', withCred({
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-csrf-token': csrf },
    body: JSON.stringify(body)
  }));
  if (!r.ok) {
    const j = await r.json().catch(()=>({}));
    alert('Error al crear: ' + (j.error || r.status));
    return;
  }
  const j = await r.json();
  const productId = j.id;

  // 2) Asociar imágenes extra (todas; el backend las ordena por posición)
  if (imagesUploaded.length) {
    await fetch('/api/admin/product-images', withCred({
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-csrf-token': csrf },
      body: JSON.stringify({ productId, images: imagesUploaded })
    })).catch(()=>{});
  }

  // Reset UI
  imagesUploaded = [];
  ['name','price','stock','category','description','image_url'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('featured').checked = false;
  document.getElementById('files').value = '';
  document.getElementById('preview').innerHTML = '';
  await load();
}

// Wiring (reemplazá la línea del botón upload)


// Wire
document.getElementById('btn-login').onclick  = login;
document.getElementById('btn-logout').onclick = logout;
document.getElementById('btn-create').onclick = create;
document.getElementById('btn-upload').onclick = uploadFiles;

// Init (una sola prueba silenciosa de sesión)
(async () => {
  loadSidFromStorage();
  await tryFetchMeOnce(); // si no hay sesión, queda deslogueado (no vuelve a spamear)
  load();
})();
