export function formatCurrency(n) {
  const num = typeof n === 'string' ? Number(n) : n;
  try {
    return new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS', maximumFractionDigits: 0 }).format(num);
  } catch {
    return `$${num}`;
  }
}

// Escapá cualquier string antes de meterlo en innerHTML
export function escapeHtml(str = '') {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}
