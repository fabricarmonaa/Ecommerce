// public_site/js/app.js
import { formatCurrency, escapeHtml } from './utils.js';
import { currentCart, renderCart } from './cart.js';

const catalogEl = document.getElementById('catalog');
const qEl       = document.getElementById('q');
const catEl     = document.getElementById('cat');
const prevEl    = document.getElementById('prev');
const nextEl    = document.getElementById('next');
const searchBtn = document.getElementById('btn-search');

const state = { page: 1, limit: 12, total: 0, q: '', category: '' };

async function loadCatalog() {
  try {
    const params = new URLSearchParams({
      limit: String(state.limit),
      offset: String((state.page - 1) * state.limit),
      q: state.q || '',
      category: state.category || ''
    });

    const res = await fetch('/api/products?' + params.toString(), { headers: { 'Accept':'application/json' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const j = await res.json();
    const items = Array.isArray(j) ? j : (j.items || []);
    state.total = Number((Array.isArray(j) ? items.length : j.total) || items.length || 0);

    if (!items.length) {
      if (catalogEl) catalogEl.innerHTML = '<p>No hay productos cargados.</p>';
      updatePager();
      return;
    }

    // Batch de galerías y normalización de keys
    const ids = items.map(p => p.id);
    let imagesByProduct = {};
    const r2 = await fetch('/api/product-images-batch?ids=' + ids.join(','), { headers: { 'Accept':'application/json' } });
    if (r2.ok) {
      const jb = await r2.json().catch(()=> ({}));
      const rawMap = jb.imagesByProduct || jb.items || jb || {};
      imagesByProduct = {};
      Object.keys(rawMap).forEach(k => {
        const nk = Number(k);
        if (!Number.isNaN(nk)) imagesByProduct[nk] = rawMap[k];
      });
    }

    renderCatalogWithGalleries(items, imagesByProduct);
    updatePager();
  } catch (err) {
    if (catalogEl) catalogEl.innerHTML = `<p>Error cargando catálogo: ${escapeHtml(err?.message || String(err))}</p>`;
  }
}

function makeCardWithCarousel(p, images) {
  const el = document.createElement('article');
  el.className = 'card';

  const merged = [];
  const pushUnique = u => { if (u && !merged.includes(u)) merged.push(u); };
  pushUnique(p.image_url);
  if (Array.isArray(images)) images.forEach(pushUnique);
  const gallery = merged.slice(0,5);
  if (!gallery.length) gallery.push('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400"><rect width="100%" height="100%" fill="%230c0d1a"/><text x="50%" y="50%" fill="%23fff" font-size="24" text-anchor="middle" dy=".3em">Sin imagen</text></svg>');

  const carousel = document.createElement('div'); carousel.className = 'carousel';
  const track = document.createElement('div'); track.className = 'track';
  gallery.forEach(src => { const im = document.createElement('img'); im.src = src; im.alt = p.name || ''; track.appendChild(im); });
  carousel.appendChild(track);

  const prev = document.createElement('button'); prev.className = 'nav prev'; prev.textContent = '‹';
  const next = document.createElement('button'); next.className = 'nav next'; next.textContent = '›';
  const dots = document.createElement('div'); dots.className = 'dots';
  const dotsEls = gallery.map((_,i)=>{ const d=document.createElement('span'); d.className='dot'+(i===0?' active':''); dots.appendChild(d); return d; });
  carousel.appendChild(prev); carousel.appendChild(next); carousel.appendChild(dots);

  let idx = 0;
  const go = i => { idx = (i + gallery.length) % gallery.length; track.style.transform=`translateX(-${idx*100}%)`; dotsEls.forEach((d,k)=>d.classList.toggle('active', k===idx)); };
  prev.onclick = ()=> go(idx-1);
  next.onclick = ()=> go(idx+1);

  el.appendChild(carousel);

  const info = document.createElement('div'); info.className = 'info';
  const h3 = document.createElement('h3'); h3.textContent = p.name + (p.featured ? ' 🌟' : '');
  const desc = document.createElement('p'); desc.textContent = (p.description || '').slice(0, 100);
  const price = document.createElement('p'); price.className = 'price'; price.textContent = formatCurrency(p.price);

  const actions = document.createElement('div'); actions.className = 'actions';
  const btn = document.createElement('button'); btn.className = 'add'; btn.textContent = 'Agregar al carrito';
  btn.addEventListener('click', () => { currentCart.addItem({ id: p.id, name: p.name, price: p.price }, 1); renderCart(document.getElementById('cart-list'), currentCart); });

  actions.appendChild(btn);
  info.appendChild(h3); info.appendChild(desc); info.appendChild(price); info.appendChild(actions);
  el.appendChild(info);

  return el;
}

function renderCatalogWithGalleries(items, imagesByProduct) {
  if (!catalogEl) return;
  catalogEl.innerHTML = '';
  for (const p of items) {
    const imgs = imagesByProduct?.[p.id] || [];
    catalogEl.appendChild(makeCardWithCarousel(p, imgs));
  }
}

function updatePager() {
  const maxPage = Math.max(1, Math.ceil(state.total / state.limit));
  if (prevEl) prevEl.disabled = state.page <= 1;
  if (nextEl) nextEl.disabled = state.page >= maxPage;
}

// Boot
document.addEventListener('DOMContentLoaded', () => {
  renderCart(document.getElementById('cart-list'), currentCart);
  if (prevEl)  prevEl.addEventListener('click', () => { if (state.page > 1) { state.page--; loadCatalog(); } });
  if (nextEl)  nextEl.addEventListener('click', () => { state.page++; loadCatalog(); });
  if (searchBtn) searchBtn.addEventListener('click', () => {
    state.q = (qEl?.value || '').trim();
    state.category = (catEl?.value || '').trim();
    state.page = 1;
    loadCatalog();
  });
  loadCatalog();
});
