import { formatCurrency } from './utils.js';

class Cart {
  constructor(){ this.items = JSON.parse(localStorage.getItem('cart')||'[]'); }
  save(){ localStorage.setItem('cart', JSON.stringify(this.items)); document.dispatchEvent(new CustomEvent('cart:updated')); }
  addItem(prod, qty=1){ const i=this.items.find(x=>x.id===prod.id); if(i) i.qty+=qty; else this.items.push({...prod, qty}); this.save(); }
  remove(id){ this.items = this.items.filter(x=>x.id!==id); this.save(); }
  update(id,qty){ const i=this.items.find(x=>x.id===id); if(!i)return; i.qty=Math.max(1,qty|0); this.save(); }
  clear(){ this.items=[]; this.save(); }
  total(){ return this.items.reduce((a,b)=>a + Number(b.price||0)*b.qty, 0); }
}
export const currentCart = new Cart();

export function renderCart(container, cart=currentCart){
  if(!container) return;
  if(cart.items.length===0){ container.innerHTML = '<p>Tu carrito está vacío.</p>'; return; }
  container.innerHTML = cart.items.map(it=>`
    <div class="cart-row">
      <div>${it.name}</div>
      <input type="number" min="1" value="${it.qty}" data-id="${it.id}" class="qty"/>
      <div>${formatCurrency((it.price||0)*it.qty)}</div>
      <button class="cart-remove" data-id="${it.id}">×</button>
    </div>
  `).join('');
  container.querySelectorAll('.qty').forEach(inp=>{
    inp.onchange = ()=> currentCart.update(Number(inp.dataset.id), Number(inp.value));
  });
  container.querySelectorAll('.cart-remove').forEach(btn=>{
    btn.onclick = ()=> currentCart.remove(Number(btn.dataset.id));
  });
}
