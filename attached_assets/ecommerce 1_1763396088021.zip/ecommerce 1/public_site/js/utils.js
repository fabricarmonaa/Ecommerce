export function formatCurrency(n){return new Intl.NumberFormat('es-AR',{style:'currency',currency:'ARS'}).format(Number(n||0));}
export function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
