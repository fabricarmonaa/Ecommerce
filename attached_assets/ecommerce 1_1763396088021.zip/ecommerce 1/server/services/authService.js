import bcrypt from 'bcryptjs';

import { findByUsername, createAdminIfNotExists } from '../repositories/usersRepository.js';
import { createSession, destroySession, getSession, rotateCsrf } from '../repositories/sessionsRepository.js';

/**
 * Crea el admin si no existe. Guarda password hasheado.
 */
export async function ensureAdminSeed(db, { username, password }) {
  const hash = await bcrypt.hash(password, 12);
  await createAdminIfNotExists(db, username, hash);
}

/**
 * Login: valida credenciales, crea sesión y devuelve tokens.
 */
export async function login(db, username, password, { sessionTtlMs } = {}) {
  const user = await findByUsername(db, username);
  if (!user) return null;

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return null;

  const { sid, csrf, exp } = createSession({ userId: user.id, username: user.username, ttlMs: sessionTtlMs });
  return { sid, csrf, exp, user: { id: user.id, username: user.username } };
}

/**
 * Logout: destruye sesión.
 */
export async function logout(sid) {
  destroySession(sid);
}

/**
 * Obtiene la data de sesión por sid.
 */
export function getSessionData(sid) {
  return getSession(sid);
}

/**
 * Rota el token CSRF de una sesión.
 */
export function newCsrf(sid) {
  return rotateCsrf(sid);
}