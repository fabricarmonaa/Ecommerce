// server/controllers/adminProductController.js
import { sendJSON } from '../utils/response.js';
import { parseCookies } from '../utils/cookies.js';
import { getSessionData } from '../services/authService.js';
import { addImages, replaceImages, listByProduct } from '../repositories/productImagesRepository.js';
import { join, normalize } from 'node:path';
import { existsSync, unlinkSync } from 'node:fs';

function requireAdmin(req, res) {
  const cookies = parseCookies(req.headers.cookie || '');
  const sid = cookies.sid || req.headers['x-session-id'];
  const s = sid ? getSessionData(sid) : null;
  if (!s) { sendJSON(res, 401, { error: 'No autenticado' }); return null; }
  const csrf = req.headers['x-csrf-token'] || req.query?.csrf;
  if (!csrf || csrf !== s.csrf) { sendJSON(res, 403, { error: 'CSRF inválido' }); return null; }
  return s;
}

async function readJSON(req) {
  return await new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => { data += c; if (data.length > 1e6) req.destroy(); });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch(e){ reject(e);} });
    req.on('error', reject);
  });
}

export async function adminCreateProduct(req, res, ctx) {
  try {
    if (req.method !== 'POST') { res.setHeader('Allow','POST'); return sendJSON(res, 405, { error:'Method Not Allowed' }); }
    const s = requireAdmin(req, res); if (!s) return true;

    let body;
    try { body = await readJSON(req); }
    catch { return sendJSON(res, 400, { error: 'JSON inválido' }); }

    const name = String(body.name || '').trim();
    const price = Number(body.price || 0);
    const image_url = String(body.image_url || '').trim();
    const stock = Number(body.stock || 0);
    const category = (body.category || '').trim();
    const description = (body.description || '').trim();
    const featured = body.featured ? 1 : 0;

    if (!name) return sendJSON(res, 400, { error: 'Falta nombre' });
    if (!Number.isFinite(price) || price <= 0) return sendJSON(res, 400, { error: 'Precio inválido' });
    if (!image_url) return sendJSON(res, 400, { error: 'Subí al menos una imagen' });

    const sql = `INSERT INTO products (name, description, price, image_url, stock, category, featured)
                 VALUES (?, ?, ?, ?, ?, ?, ?)`;
    const [r] = await ctx.db.execute(sql, [name, description, price, image_url, stock, category, featured]);
    return sendJSON(res, 201, { id: r.insertId });
  } catch (e) {
    console.error('[ADMIN CREATE ERROR]', e);
    return sendJSON(res, 500, { error: 'Internal Server Error' });
  }
}

export async function adminUpdateProduct(req, res, ctx) {
  try {
    if (req.method !== 'PUT') { res.setHeader('Allow','PUT'); return sendJSON(res, 405, { error:'Method Not Allowed' }); }
    const s = requireAdmin(req, res); if (!s) return true;

    const id = Number(new URL(req.url, `http://${req.headers.host}`).pathname.split('/').pop());
    if (!id) return sendJSON(res, 400, { error: 'id requerido' });

    let body;
    try { body = await readJSON(req); } catch { return sendJSON(res, 400, { error: 'JSON inválido' }); }

    const fields = [];
    const values = [];
    const setField = (col, val) => { fields.push(`${col}=?`); values.push(val); };

    if ('name' in body)        setField('name', String(body.name||'').trim());
    if ('description' in body) setField('description', String(body.description||'').trim());
    if ('price' in body)       setField('price', Number(body.price||0));
    if ('image_url' in body)   setField('image_url', String(body.image_url||'').trim());
    if ('stock' in body)       setField('stock', Number(body.stock||0));
    if ('category' in body)    setField('category', String(body.category||'').trim());
    if ('featured' in body)    setField('featured', body.featured ? 1 : 0);

    if (!fields.length) return sendJSON(res, 400, { error:'Nada para actualizar' });

    values.push(id);
    const [r] = await ctx.db.execute(`UPDATE products SET ${fields.join(', ')} WHERE id=?`, values);
    if (!r.affectedRows) return sendJSON(res, 404, { error: 'producto no encontrado' });

    // Opcional: reemplazar galería si viene "images"
    if (Array.isArray(body.images)) {
      await replaceImages(ctx.db, id, body.images.slice(0, 5));
    }

    return sendJSON(res, 200, { ok: true });
  } catch (e) {
    console.error('[ADMIN UPDATE ERROR]', e);
    return sendJSON(res, 500, { error: 'Internal Server Error' });
  }
}

export async function adminDeleteProduct(req, res, ctx) {
  try {
    if (req.method !== 'DELETE') { res.setHeader('Allow','DELETE'); return sendJSON(res, 405, { error:'Method Not Allowed' }); }
    const s = requireAdmin(req, res); if (!s) return true;

    const id = Number(new URL(req.url, `http://${req.headers.host}`).pathname.split('/').pop());
    if (!id) return sendJSON(res, 400, { error: 'id requerido' });

    // Traer urls (principal + galería)
    const [[prod]] = await ctx.db.execute('SELECT image_url FROM products WHERE id=?', [id]);
    const gallery = await listByProduct(ctx.db, id);
    const urls = [];
    if (prod?.image_url) urls.push(prod.image_url);
    for (const u of gallery) if (u) urls.push(u);

    // Borrar DB (FK ya borra product_images)
    const [r] = await ctx.db.execute('DELETE FROM products WHERE id=?', [id]);
    if (!r.affectedRows) return sendJSON(res, 404, { error: 'producto no encontrado' });

    // Borrar archivos físicos dentro de /uploads (best-effort)
    const base = ctx.UPLOADS_DIR.replace(/\\/g,'/');
    for (const u of urls) {
      if (!u.startsWith('/uploads/')) continue; // solo archivos locales
      const rel = u.replace('/uploads/', '');
      const abs = normalize(join(ctx.UPLOADS_DIR, rel));
      if (!abs.replace(/\\/g,'/').startsWith(base)) continue; // path traversal guard
      try { if (existsSync(abs)) unlinkSync(abs); } catch (e) { console.warn('[DEL FILE ERR]', abs, e.message); }
    }

    return sendJSON(res, 200, { ok: true });
  } catch (e) {
    console.error('[ADMIN DELETE ERROR]', e);
    return sendJSON(res, 500, { error: 'Internal Server Error' });
  }
}
