import { sendJSON } from '../utils/response.js';
import { parseCookies } from '../utils/cookies.js';
import { getSessionData } from '../services/authService.js';
import { randomBytes } from 'node:crypto';
import { createWriteStream, existsSync, mkdirSync } from 'node:fs';
import { join, extname } from 'node:path';
import Busboy from 'busboy';

function requireAuth(req, res) {
  const cookies = parseCookies(req.headers.cookie || '');
  const sid = cookies.sid || req.headers['x-session-id'];
  const s = sid ? getSessionData(sid) : null;
  if (!s) { sendJSON(res, 401, { error: 'No autenticado' }); return null; }
  const csrf = req.headers['x-csrf-token'] || req.query?.csrf;
  if (!csrf || csrf !== s.csrf) { sendJSON(res, 403, { error: 'CSRF inválido' }); return null; }
  return s;
}
function requireAdmin(req, res) {
  const cookies = parseCookies(req.headers.cookie || '');
  const sid = cookies.sid || req.headers['x-session-id'];
  const s = sid ? getSessionData(sid) : null;
  if (!s) { sendJSON(res, 401, { error: 'No autenticado' }); return null; }
  const csrf = req.headers['x-csrf-token'] || req.query?.csrf;
  if (!csrf || csrf !== s.csrf) { sendJSON(res, 403, { error: 'CSRF inválido' }); return null; }
  return s;
}

export async function adminUpload(req, res, ctx) {
  if (req.method !== 'POST') { res.setHeader('Allow','POST'); return sendJSON(res, 405, { error: 'Method Not Allowed' }); }
  const s = requireAdmin(req, res); if (!s) return true;

  const uploadsDir = ctx.UPLOADS_DIR;
  if (!existsSync(uploadsDir)) mkdirSync(uploadsDir, { recursive: true });

  const bb = Busboy({ headers: req.headers });
  let fileSaved = false;
  let publicUrl = null;

  bb.on('file', (name, file, info) => {
    // aceptamos cualquier campo, pero si querés forzar 'image': if (name !== 'image') file.resume();
    const { filename } = info;
    const safeExt = (ext => ext && ext.length <= 6 ? ext : '')(extname(filename || '').toLowerCase());
    const fname = 'img_' + randomBytes(8).toString('hex') + safeExt;
    const absPath = join(uploadsDir, fname);
    const ws = createWriteStream(absPath);
    file.pipe(ws);
    ws.on('finish', () => {
      fileSaved = true;
      publicUrl = '/uploads/' + fname;
      console.log('[UPLOAD write]', { absPath, orig: filename || '' });
    });
    ws.on('error', (err) => {
      console.error('[UPLOAD WRITE ERROR]', err);
      file.resume();
    });
  });

  bb.on('error', (err) => {
    console.error('[UPLOAD BUSBOY ERROR]', err);
  });

  bb.on('finish', () => {
    if (!fileSaved) return sendJSON(res, 400, { error: 'No se recibió archivo' });
    return sendJSON(res, 201, { url: publicUrl });
  });

  req.pipe(bb);
}


export async function uploadImage(req, res, ctx) {
  if (req.method !== 'POST') {
    res.statusCode = 405;
    res.setHeader('Allow', 'POST');
    return sendJSON(res, 405, { error: 'Method Not Allowed' });
  }
  const s = requireAuth(req, res);
  if (!s) return true;

  const UPLOADS_DIR = ctx?.UPLOADS_DIR;
  if (!UPLOADS_DIR) return sendJSON(res, 500, { error: 'UPLOADS_DIR no configurado' });

  try {
    if (!existsSync(UPLOADS_DIR)) mkdirSync(UPLOADS_DIR, { recursive: true });
  } catch (e) {
    console.error('[UPLOAD mkdir ERROR]', e);
    return sendJSON(res, 500, { error: 'No se pudo crear /uploads' });
  }

  const bb = Busboy({ headers: req.headers, limits: { files: 1, fileSize: 5 * 1024 * 1024 } });

  let responded = false;
  let gotFile = false;
  let pending = 0;     // <- cuántas escrituras quedan (mantenemos 1 archivo por request)

  const safeEnd = (status, payload) => {
    if (responded) return;
    responded = true;
    try { sendJSON(res, status, payload); } catch {}
  };

  bb.on('file', (_field, file, info) => {
    gotFile = true;
    pending++;

    const ext = (extname(info?.filename || '').toLowerCase()) || '.jpg';
    const name = 'img_' + randomBytes(8).toString('hex') + ext;
    const absPath = join(UPLOADS_DIR, name);
    const urlPath = `/uploads/${name}`;

    console.log('[UPLOAD write]', { absPath, orig: info?.filename });

    const out = createWriteStream(absPath, { flags: 'w' });

    out.on('error', (err) => {
      console.error('[UPLOAD WRITE ERROR]', err);
      // Si falla la escritura, respondemos error
      safeEnd(500, { error: 'Write failed' });
      try { file.resume(); } catch {}
    });

    out.on('finish', () => {
      pending--;
      // Respondemos SOLO acá cuando terminó de escribirse
      if (!responded && pending === 0) safeEnd(201, { url: urlPath });
    });

    file.on('limit', () => {
      console.warn('[UPLOAD] fileSize limit reached');
      try { out.destroy(); } catch {}
      safeEnd(400, { error: 'File too large (5MB max)' });
    });

    file.on('error', (err) => {
      console.error('[UPLOAD FILE ERROR]', err);
      try { out.destroy(); } catch {}
      safeEnd(500, { error: 'Upload failed' });
    });

    file.pipe(out);
  });

  bb.on('error', (err) => {
    console.error('[UPLOAD BUSBOY ERROR]', err);
    safeEnd(500, { error: 'Upload failed' });
  });

  bb.on('close', () => {
    // NO respondemos 500 acá: esperamos a 'finish'
    if (!gotFile && !responded) {
      safeEnd(400, { error: 'No file' });
    }
  });

  req.pipe(bb);
  return true;
}
