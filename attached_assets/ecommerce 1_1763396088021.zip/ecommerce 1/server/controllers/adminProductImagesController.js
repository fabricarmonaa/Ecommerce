// server/controllers/adminProductImagesController.js
import { sendJSON } from '../utils/response.js';
import { parseCookies } from '../utils/cookies.js';
import { getSessionData } from '../services/authService.js';
import { addImages, listByProduct, listByProductIds } from '../repositories/productImagesRepository.js';

function requireAdmin(req, res) {
  const cookies = parseCookies(req.headers.cookie || '');
  const sid = cookies.sid || req.headers['x-session-id'];
  const s = sid ? getSessionData(sid) : null;
  if (!s) { sendJSON(res, 401, { error: 'No autenticado' }); return null; }
  const csrf = req.headers['x-csrf-token'] || req.query?.csrf;
  if (!csrf || csrf !== s.csrf) { sendJSON(res, 403, { error: 'CSRF inválido' }); return null; }
  return s;
}

async function readJSON(req) {
  return await new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => { data += c; if (data.length > 1e6) req.destroy(); });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch(e){ reject(e);} });
    req.on('error', reject);
  });
}

// POST /api/admin/product-images { productId, images: [url1, ...] }
export async function adminAddProductImages(req, res, ctx) {
  try {
    if (req.method !== 'POST') { res.setHeader('Allow','POST'); return sendJSON(res, 405, { error:'Method Not Allowed' }); }
    const s = requireAdmin(req, res); if (!s) return true;

    const body = await readJSON(req);
    const productId = Number(body.productId || 0);
    const images = Array.isArray(body.images) ? body.images.slice(0, 5) : [];
    if (!productId) return sendJSON(res, 400, { error: 'productId requerido' });
    if (!images.length) return sendJSON(res, 400, { error: 'images vacío' });

    const n = await addImages(ctx.db, productId, images);
    return sendJSON(res, 201, { added: n });
  } catch (e) {
    console.error('[ADMIN ADD IMAGES ERROR]', e);
    return sendJSON(res, 500, { error: 'Internal Server Error' });
  }
}

// GET /api/product-images?productId=123
export async function publicListProductImages(req, res, ctx) {
  const productId = Number(req.query?.productId || 0);
  if (!productId) return sendJSON(res, 400, { error: 'productId requerido' });
  const images = await listByProduct(ctx.db, productId);
  return sendJSON(res, 200, { images });
}

// GET /api/product-images-batch?ids=1,2,3
export async function publicListProductImagesBatch(req, res, ctx) {
  const ids = String(req.query?.ids || '')
    .split(',')
    .map(x => Number(x.trim()))
    .filter(Boolean);
  if (!ids.length) return sendJSON(res, 400, { error: 'ids requerido' });
  const map = await listByProductIds(ctx.db, ids);
  return sendJSON(res, 200, { imagesByProduct: map });
}
