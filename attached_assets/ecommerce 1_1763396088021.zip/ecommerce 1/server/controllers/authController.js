import { parseBody } from '../core/parseBody.js';
import { sendJSON } from '../utils/response.js';
import { parseCookies, setCookie } from '../utils/cookies.js';
import { ensureAdminSeed, login, logout, getSessionData, newCsrf } from '../services/authService.js';

const ONE_MIN = 60 * 1000;

function isSecure() {
  return process.env.NODE_ENV === 'production';
}

export async function bootstrapAdmin(req, res, ctx) {
  const username = process.env.ADMIN_USERNAME || 'admin';
  const password = process.env.ADMIN_PASSWORD || 'admin123';
  await ensureAdminSeed(ctx.db, { username, password });
  return sendJSON(res, 200, { ok: true, created: true });
}

const rate = new Map(); // ip -> { count, until }

export async function adminLogin(req, res, ctx) {
  const ip = req.socket.remoteAddress || 'local';
  const entry = rate.get(ip);
  const now = Date.now();
  if (entry && entry.until > now) {
    return sendJSON(res, 429, { error: 'Demasiados intentos, esperá un minuto.' });
  }

  const body = await parseBody(req);
  const username = String(body?.username || '');
  const password = String(body?.password || '');

  const ONE_MIN = 60 * 1000;
  const sessionTtlMs = (Number(process.env.SESSION_TTL_MIN || 120)) * ONE_MIN;

  const out = await login(ctx.db, username, password, { sessionTtlMs });

  if (!out) {
    const c = (entry?.count || 0) + 1;
    const until = c >= 5 ? now + ONE_MIN : now;
    rate.set(ip, { count: c, until });
    return sendJSON(res, 401, { error: 'Credenciales inválidas' });
  }

  // set cookie
  const maxAgeSec = Math.floor(sessionTtlMs / 1000);
  setCookie(res, 'sid', out.sid, { httpOnly: true, sameSite: 'Lax', secure: false, maxAgeSec });

  // IMPORTANTE: devolver también el sid para fallback en header
  return sendJSON(res, 200, { ok: true, user: out.user, csrf: out.csrf, exp: out.exp, sid: out.sid });

}

export async function adminLogout(req, res) {
  const cookies = parseCookies(req.headers.cookie || '');
  const sid = cookies.sid;
  if (sid) await logout(sid);
  // invalido cookie
  setCookie(res, 'sid', '', { httpOnly: true, sameSite: 'Lax', secure: isSecure(), maxAgeSec: 0 });
  return sendJSON(res, 200, { ok: true });
}

export async function adminMe(req, res) {
  const cookies = parseCookies(req.headers.cookie || '');
  const sid = cookies.sid || req.headers['x-session-id'];
  const s = sid ? getSessionData(sid) : null;
  if (!s) return sendJSON(res, 401, { error: 'No autenticado' });
  // DEVOLVER SIEMPRE csrf
  return sendJSON(res, 200, { user: s.user || 'owner', csrf: s.csrf });
}

export async function adminCsrf(req, res) {
  const cookies = parseCookies(req.headers.cookie || '');
  const sid = cookies.sid;
  const token = sid ? newCsrf(sid) : null;
  if (!token) return sendJSON(res, 401, { error: 'No autenticado' });
  return sendJSON(res, 200, { csrf: token });
}
