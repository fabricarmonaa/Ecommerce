import { sendJSON } from '../utils/response.js';

export async function getEnvPublic(req, res) {
  // Exponemos solo lo necesario para el front
  const phone = (process.env.WHATSAPP_PHONE || '').replace(/[^\d]/g, '');
  return sendJSON(res, 200, { WHATSAPP_PHONE: phone });
}
