// server/controllers/productsController.js
import { sendJSON } from '../utils/response.js';
import { findAll } from '../repositories/productsRepository.js';

export async function getProducts(req, res, ctx) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const limit = Number(url.searchParams.get('limit') || 12);
  const offset = Number(url.searchParams.get('offset') || 0);
  const q = (url.searchParams.get('q') || '').trim();
  const category = (url.searchParams.get('category') || '').trim();

  const { items, total } = await findAll(ctx.db, { limit, offset, q, category });
  return sendJSON(res, 200, { items, total });
}


export async function getProductById(req, res, ctx) {
  const id = Number(req.query.id);
  if (!id) return sendJSON(res, 400, { error: 'id requerido' });
  const item = await getProduct(ctx.db, id);
  if (!item) return sendJSON(res, 404, { error: 'producto no encontrado' });
  return sendJSON(res, 200, item);
}
