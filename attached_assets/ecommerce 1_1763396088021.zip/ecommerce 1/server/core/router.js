// server/core/router.js (ESM)
import { sendJSON } from '../utils/response.js';
import { getEnvPublic } from '../controllers/envController.js';

import {
  adminAddProductImages,
  publicListProductImages,
  publicListProductImagesBatch,
} from '../controllers/adminProductImagesController.js';

import {
  getProducts,
  getProductById,
} from '../controllers/productsController.js';

import {
  adminLogin,
  adminLogout,
  adminMe,
  adminCsrf,
  bootstrapAdmin,
} from '../controllers/authController.js';

// OJO: respetamos tu archivo plural actual
import {
  adminCreateProduct,
  adminUpdateProduct,
  adminDeleteProduct,
} from '../controllers/adminProductsController.js';

import { uploadImage } from '../controllers/uploadController.js';

export async function router(req, res, ctx) {
  // httpServer ya suele setear req.pathname y req.query;
  // si no, los calculamos defensivamente:
  let pathname = req.pathname;
  if (!pathname) {
    const url = new URL(req.url, `http://${req.headers.host}`);
    pathname = url.pathname;
    req.query = Object.fromEntries(url.searchParams.entries());
  }
  const method = req.method;

  // ---------- Health ----------
  if (method === 'GET' && pathname === '/api/health') {
    return sendJSON(res, 200, { ok: true, name: process.env.APP_NAME || 'eCommerce', time: Date.now() });
  }
  if (method === 'GET' && pathname === '/api/health/db') {
    try {
      const [rows] = await ctx.db.query('SELECT NOW() AS now');
      return sendJSON(res, 200, { ok: true, now: rows[0].now });
    } catch (e) {
      return sendJSON(res, 503, { ok: false, error: e.code || String(e) });
    }
  }

  // ---------- Público ----------
  if (method === 'GET' && pathname === '/api/env') return getEnvPublic(req, res, ctx);

  // Catálogo
  if (method === 'GET' && pathname === '/api/products') return getProducts(req, res, ctx);
  if (method === 'GET' && pathname === '/api/product')  return getProductById(req, res, ctx);

  // Imágenes públicas
  if (method === 'GET' && pathname === '/api/product-images')       return publicListProductImages(req, res, ctx);
  if (method === 'GET' && pathname === '/api/product-images-batch') return publicListProductImagesBatch(req, res, ctx);

  // ---------- Admin / Auth ----------
  if (method === 'POST' && pathname === '/api/admin/bootstrap') return bootstrapAdmin(req, res, ctx);
  if (method === 'POST' && pathname === '/api/admin/login')     return adminLogin(req, res, ctx);
  if (method === 'POST' && pathname === '/api/admin/logout')    return adminLogout(req, res, ctx);
  if (method === 'GET'  && pathname === '/api/admin/me')        return adminMe(req, res, ctx);
  if (method === 'GET'  && pathname === '/api/admin/csrf')      return adminCsrf(req, res, ctx);

  // Galería admin (guardar URLs de imágenes adicionales)
  if (method === 'POST' && pathname === '/api/admin/product-images') return adminAddProductImages(req, res, ctx);

  // ---------- Upload (GET para prueba, POST para subir) ----------
  if (method === 'GET'  && pathname === '/api/admin/upload') return uploadImage(req, res, ctx);
  if (method === 'POST' && pathname === '/api/admin/upload') return uploadImage(req, res, ctx);

  // ---------- Admin CRUD ----------
  // Crear
  if (method === 'POST' && pathname === '/api/admin/product') {
    return adminCreateProduct(req, res, ctx);
  }

  // Update/Delete con id en path: /api/admin/product/:id
  if (pathname.startsWith('/api/admin/product/')) {
    const idStr = pathname.split('/').pop();
    req.params = { id: Number(idStr) || 0 };

    if (method === 'PUT')    return adminUpdateProduct(req, res, ctx);
    if (method === 'DELETE') return adminDeleteProduct(req, res, ctx);
  }

  // ---------- Fallback ----------
  // Si es /api/* y nada matcheó, devolvemos 404 JSON
  if (pathname.startsWith('/api/')) {
    return sendJSON(res, 404, { error: 'Not Found' });
  }

  // Para rutas no-API dejamos que httpServer -> serveStatic atienda (public_site, admin_site, uploads)
  return false;
}
