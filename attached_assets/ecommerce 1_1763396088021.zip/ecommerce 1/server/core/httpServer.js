import http from 'node:http';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

import { serveStatic } from './serveStatic.js';
import { setSecurityHeaders } from './securityHeaders.js';
import { router } from './router.js';
import { getDb } from './db.js';

const __filename = fileURLToPath(import.meta.url);
const ROOT_DIR   = join(dirname(__filename), '..', '..');
const UPLOADS_DIR = join(ROOT_DIR, 'uploads');
const PUBLIC_SITE = join(ROOT_DIR, 'public_site');
const ADMIN_SITE  = join(ROOT_DIR, 'admin_site');

// Lazy DB (no bloquea arranque ni estáticos)
let dbInstance = null;
async function getDbLazy() {
  if (!dbInstance) dbInstance = await getDb();
  return dbInstance;
}

export async function startServer(port = 3000) {
    console.log("tuleperaconlapapaya");
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, `http://${req.headers.host}`);
      req.pathname = url.pathname;
      req.query = Object.fromEntries(url.searchParams.entries());

      setSecurityHeaders(res);

      // 1) estáticos...
      const served = await serveStatic(req, res, { PUBLIC_SITE, ADMIN_SITE, UPLOADS_DIR });
      if (served) return;

      // 2) API (acá SIEMPRE pasamos UPLOADS_DIR)
          if (req.pathname.startsWith('/api/')) {
      const db = await getDbLazy();
      const handled = await router(req, res, { db, UPLOADS_DIR });
          
      if (handled === false && !res.headersSent) {
        res.statusCode = 404;
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        res.end(JSON.stringify({ error: 'Not Found' }));
      }
      return;
    }

        // 3) 404
      if (!res.headersSent) {
        res.statusCode = 404;
        res.setHeader('Content-Type', 'text/plain; charset=utf-8');
        res.end('Not Found');
      }
    } catch (err) {
      console.error('[HTTP ERROR]', err);
      if (!res.headersSent) {
        res.statusCode = 500;
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
      }
      res.end(JSON.stringify({ error: 'Internal Server Error' }));
    }
  });

  server.listen(port, () => {
    console.log("tuleperaconlapapaya");
    console.log(`▶ Server listening on http://localhost:${port}`);
  });

  return server;
}
