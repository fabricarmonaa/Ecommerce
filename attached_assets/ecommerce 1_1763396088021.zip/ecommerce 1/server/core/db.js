// server/core/db.js
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const APP_PORT = Number(process.env.PORT || 3000);

// Lee env con defaults típicos de XAMPP
const MYSQL_HOST = process.env.MYSQL_HOST || process.env.DB_HOST ;
const MYSQL_USER = process.env.MYSQL_USER || process.env.DB_USER;
const MYSQL_PASSWORD = process.env.MYSQL_PASSWORD ?? process.env.DB_PASS;
const MYSQL_DB = process.env.MYSQL_DB || process.env.DB_NAME;

// Blindaje de puerto para no usar 3000 por error
function pickMysqlPort() {
  const cand = Number(process.env.MYSQL_PORT ?? process.env.DB_PORT ?? 3306);
  return (Number.isFinite(cand) && cand > 0 && cand < 65536 && cand !== APP_PORT) ? cand : 3306;
}
const MYSQL_PORT = pickMysqlPort();

// ---- Pool + retry/ping
let pool;

function createPool() {
  console.log(`[DB] host=${MYSQL_HOST} user=${MYSQL_USER} db=${MYSQL_DB} port=${MYSQL_PORT}`);
  pool = mysql.createPool({
    host: MYSQL_HOST,
    user: MYSQL_USER,
    password: MYSQL_PASSWORD,
    database: MYSQL_DB,
    port: MYSQL_PORT,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    // estabilidad
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
    charset: 'utf8mb4',
    supportBigNumbers: true,
    dateStrings: true,
  });
  return pool;
}

async function pingWithRetry(maxAttempts = 8) {
  let lastErr;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      await pool.query('SELECT 1');
      return true;
    } catch (err) {
      lastErr = err;
      const backoff = Math.min(5000, 250 * attempt); // 250ms -> 5s
      console.warn(`[DB] intento ${attempt}/${maxAttempts} falló (${err.code || err.message}). Reintentando en ${backoff}ms...`);
      await new Promise(r => setTimeout(r, backoff));
      // recrear pool por si quedó en mal estado
      createPool();
    }
  }
  console.error('[DB] no se pudo conectar después de varios intentos:', lastErr?.code || lastErr?.message);
  throw lastErr;
}

export async function getDb() {
  if (!pool) createPool();
  await pingWithRetry(); // garantiza conexión viva
  return pool;
}
