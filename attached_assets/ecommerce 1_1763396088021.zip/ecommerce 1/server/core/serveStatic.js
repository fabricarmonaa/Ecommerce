// server/core/serveStatic.js (fragmento clave)
import { createReadStream, promises as fs } from 'node:fs';
import { join, normalize } from 'node:path';
import { getContentType } from '../utils/mime.js';

function safePath(rootDir, pathname) {
  let urlPath = pathname.replace(/^\/+/, '');
  urlPath = normalize(urlPath).replace(/^(\.\.(\/|\\|$))+/, '');
  return join(rootDir, urlPath);
}

async function tryServe(res, filePath, method) {
  try {
    const stat = await fs.stat(filePath);
    if (!stat.isFile()) return false;
    res.statusCode = 200;
    res.setHeader('Content-Type', getContentType(filePath));
    if (method === 'HEAD') { res.end(); return true; }
    createReadStream(filePath).pipe(res);
    return true;
  } catch { return false; }
}

export async function serveStatic(req, res, { PUBLIC_SITE, ADMIN_SITE, UPLOADS_DIR }) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return false;
  let { pathname } = req;

  // /owner y /owner/ -> /owner/login.html
  if (pathname === '/owner' || pathname === '/owner/') pathname = '/owner/login';

  // 1) uploads
  if (pathname.startsWith('/uploads/')) {
    const filePath = safePath(UPLOADS_DIR, pathname.replace('/uploads/',''));
    return await tryServe(res, filePath, req.method);
  }

  // 2) owner (admin_site)
  if (pathname.startsWith('/owner/')) {
    let rel = pathname.replace('/owner/','');
    // si viene sin extensión, asumí .html
    if (!/\.[a-z0-9]+$/i.test(rel)) rel += '.html';
    const filePath = safePath(ADMIN_SITE, rel);
    return await tryServe(res, filePath, req.method);
  }

  // 3) público (public_site) — soporta /, /index, /algo (sin extensión => .html)
  let pub = pathname === '/' ? '/index.html' : pathname;
  if (!/\.[a-z0-9]+$/i.test(pub)) pub += '.html';
  // excepción: assets, css, js, favicon ya vienen con extensión
  if (pathname.startsWith('/assets/') || pathname.startsWith('/css/') || pathname.startsWith('/js/') || pathname === '/favicon.ico') {
    pub = pathname;
  }
  const filePath = safePath(PUBLIC_SITE, pub.replace(/^\/+/,''));
  return await tryServe(res, filePath, req.method);
}
