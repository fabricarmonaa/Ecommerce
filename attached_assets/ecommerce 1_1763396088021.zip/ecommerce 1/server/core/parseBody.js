export async function parseBody(req) {
  if (req.method !== 'POST' && req.method !== 'PUT' && req.method !== 'DELETE') return null;

  const contentType = (req.headers['content-type'] || '').split(';')[0].trim();
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString('utf8');

  if (!raw) return null;

  if (contentType === 'application/json') {
    try { return JSON.parse(raw); } catch { return null; }
  }
  if (contentType === 'application/x-www-form-urlencoded') {
    return Object.fromEntries(new URLSearchParams(raw));
  }
  return raw; // texto plano si llega
}
