import { promises as fs } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { join } from 'node:path';

export async function parseMultipart(req, { maxSize = 5 * 1024 * 1024 } = {}) {

  const ct = req.headers['content-type'] || '';
  const m = ct.match(/multipart\/form-data;\s*boundary=(.+)/i);
  if (!m) throw new Error('Content-Type no es multipart/form-data');

  const boundary = '--' + m[1];
  const chunks = [];
  let size = 0;
  for await (const ch of req) {
    size += ch.length;
    if (size > maxSize) throw new Error('Archivo demasiado grande');
    chunks.push(ch);
  }
  const buffer = Buffer.concat(chunks);
  const parts = buffer.toString('binary').split(boundary).slice(1, -1);

  const fields = {};
  const files = [];

  for (const part of parts) {
    const [rawHeaders, rawBody] = part.split('\r\n\r\n');
    if (!rawBody) continue;
    const body = rawBody.slice(0, -2); // remove trailing \r\n
    const headers = rawHeaders.split('\r\n').filter(Boolean);

    const disp = headers.find(h => h.toLowerCase().startsWith('content-disposition')) || '';
    const nameMatch = disp.match(/name="([^"]+)"/i);
    const filenameMatch = disp.match(/filename="([^"]*)"/i);

    const ctype = (headers.find(h => h.toLowerCase().startsWith('content-type')) || '').split(':')[1]?.trim()?.toLowerCase();

    if (!filenameMatch || !filenameMatch[1]) {
      const name = nameMatch?.[1] || 'field';
      fields[name] = Buffer.from(body, 'binary').toString('utf8');
      continue;
    }

    const name = nameMatch?.[1] || 'file';
    const filename = filenameMatch[1];
    const contentType = ctype || 'application/octet-stream';
    const bin = Buffer.from(body, 'binary');

    files.push({ name, filename, contentType, data: bin });
  }

  return { fields, files };
}

export async function saveUpload({
  file,
  destDir,
  // Aceptamos jpg/jpeg/jfif/png/webp (los móviles suelen mandar image/jpeg para .jpg/.jfif)
  allowed = ['image/jpeg','image/pjpeg','image/png','image/webp'],
  prefix = 'img_'
}) {
  if (!allowed.includes(file.contentType)) throw new Error('Tipo de archivo no permitido');
  const ext = ({
    'image/jpeg': '.jpg',
    'image/pjpeg': '.jpg',
    'image/png': '.png',
    'image/webp': '.webp'
  })[file.contentType] || '';
  const safe = prefix + randomBytes(8).toString('hex') + ext;
  const full = join(destDir, safe);
  await fs.writeFile(full, file.data);
  return { filename: safe, path: full, url: '/uploads/' + safe };
}
