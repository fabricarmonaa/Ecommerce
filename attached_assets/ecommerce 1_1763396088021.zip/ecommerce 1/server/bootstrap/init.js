// server/bootstrap/init.js
import bcrypt from 'bcrypt';

export async function initFirstRun(db) {
  // 1) Asegura tabla users (mínimo viable)
  await db.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(100) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      role ENUM('admin','user') DEFAULT 'admin',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // 2) Si no hay usuarios, crea admin a partir de .env
  const [rows] = await db.execute(`SELECT COUNT(*) AS c FROM users`);
  const hasUsers = Number(rows?.[0]?.c || 0) > 0;
  if (hasUsers) return;

  const username = process.env.ADMIN_USERNAME || 'admin';
  const password = process.env.ADMIN_PASSWORD || 'admin123';

  const hash = await bcrypt.hash(password, 12);
  await db.execute(
    `INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'admin')`,
    [username, hash]
  );

  console.log(
    `[INIT] Usuario admin creado automáticamente: ${username}. ` +
    `Cambiá ADMIN_USERNAME/ADMIN_PASSWORD en .env y reiniciá cuando quieras.`
  );
}
