import { listProducts, getProduct } from '../services/productsService.js';
import { sendJSON } from '../utils/response.js';

export async function getProducts(req, res, ctx) {
  const limit = Number(req.query.limit ?? 20);
  const offset = Number(req.query.offset ?? 0);
  const data = await listProducts(ctx.db, { limit, offset });
  return sendJSON(res, 200, data);
}

export async function getProductById(req, res, ctx) {
  const id = Number(req.query.id);
  if (!id) return sendJSON(res, 400, { error: 'id requerido' });
  const item = await getProduct(ctx.db, id);
  if (!item) return sendJSON(res, 404, { error: 'producto no encontrado' });
  return sendJSON(res, 200, item);
}
