export async function findAll(db, { limit=12, offset=0, q='', category='' } = {}) {
  const where = [];
  const args  = [];

  if (q) {
    where.push('(name LIKE ? OR description LIKE ?)');
    args.push(`%${q}%`, `%${q}%`);
  }
  if (category) {
    where.push('category = ?');
    args.push(category);
  }
  const whereSql = where.length ? ('WHERE ' + where.join(' AND ')) : '';

  const [rows] = await db.query(
    `SELECT SQL_CALC_FOUND_ROWS id, name, description, price, image_url, stock, category, featured
       FROM products
       ${whereSql}
       ORDER BY featured DESC, id DESC
       LIMIT ? OFFSET ?`,
    [...args, Number(limit), Number(offset)]
  );
  const [[{ 'FOUND_ROWS()': total }]] = await db.query('SELECT FOUND_ROWS()');
  return { items: rows, total: Number(total || 0) };
}


export async function countAll(db, { q = '', category = '' } = {}) {
  const where = [];
  const params = [];
  if (q) {
    where.push(`(name LIKE ? OR description LIKE ?)`);
    params.push(`%${q}%`, `%${q}%`);
  }
  if (category) {
    where.push(`category = ?`);
    params.push(category);
  }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const [r] = await db.execute(`SELECT COUNT(*) AS total FROM products ${whereSql}`, params);
  return r[0]?.total || 0;
}

export async function findById(db, id) {
  const [rows] = await db.execute(
    `SELECT id, name, description, price, image_url, stock, category, featured
     FROM products
     WHERE id = ?`,
    [id]
  );
  return rows[0] || null;
}

export async function createProduct(db, { name, description, price, image_url, stock = 0, category, featured = 0 }) {
  const [r] = await db.execute(
    `INSERT INTO products (name, description, price, image_url, stock, category, featured)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [name, description, price, image_url, stock, category, featured ? 1 : 0]
  );
  return r.insertId;
}

export async function updateProduct(db, id, patch) {
  const fields = [];
  const values = [];
  for (const [k, v] of Object.entries(patch)) {
    fields.push(`${k} = ?`);
    values.push(k === 'featured' ? (v ? 1 : 0) : v);
  }
  if (!fields.length) return 0;
  values.push(id);
  const [r] = await db.execute(
    `UPDATE products SET ${fields.join(', ')} WHERE id = ?`,
    values
  );
  return r.affectedRows > 0;
}

export async function deleteProduct(db, id) {
  const [r] = await db.execute(`DELETE FROM products WHERE id = ?`, [id]);
  return r.affectedRows > 0;
}
