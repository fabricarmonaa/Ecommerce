// server/repositories/sessionsRepository.js
import { randomBytes } from 'node:crypto';

const sessions = new Map();

/**
 * Crea una sesión en memoria.
 * data: { userId, username, ttlMs? }
 */
export function createSession(data = {}) {
  const sid  = randomBytes(16).toString('hex');
  const csrf = randomBytes(16).toString('hex');

  const now = Date.now();
  const ttl = Number(data.ttlMs || 1000 * 60 * 60 * 6); // 6 horas por defecto
  const exp = now + ttl;

  sessions.set(sid, { ...data, csrf, createdAt: now, exp });
  return { sid, csrf, exp };
}

export function getSession(sid) {
  const s = sessions.get(sid);
  if (!s) return null;
  // expirar
  if (s.exp && Date.now() > s.exp) {
    sessions.delete(sid);
    return null;
  }
  return s;
}

export function destroySession(sid) {
  sessions.delete(sid);
}

export function rotateCsrf(sid) {
  const s = sessions.get(sid);
  if (!s) return null;
  s.csrf = randomBytes(16).toString('hex');
  return s.csrf;
}
