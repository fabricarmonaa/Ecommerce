// server/repositories/productImagesRepository.js
export async function addImages(db, productId, urls = []) {
  const list = urls.filter(Boolean).slice(0, 5);
  if (!list.length) return 0;

  const values = [];
  const placeholders = list.map((u, i) => {
    values.push(productId, u, i);
    return '(?, ?, ?)';
  }).join(',');

  const sql = `INSERT INTO product_images (product_id, url, position) VALUES ${placeholders}`;
  const [result] = await db.execute(sql, values);
  return result.affectedRows || 0;
}

export async function replaceImages(db, productId, urls = []) {
  await db.execute('DELETE FROM product_images WHERE product_id=?', [productId]);
  return addImages(db, productId, urls);
}

export async function listByProduct(db, productId) {
  const [rows] = await db.execute(
    'SELECT url FROM product_images WHERE product_id=? ORDER BY position, id',
    [productId]
  );
  return rows.map(r => r.url);
}

export async function listByProductIds(db, ids = []) {
  if (!ids.length) return {};
  const placeholders = ids.map(()=>'?').join(',');
  const [rows] = await db.query(
    `SELECT product_id, url FROM product_images WHERE product_id IN (${placeholders}) ORDER BY product_id, position, id`,
    ids
  );
  const map = {};
  for (const r of rows) {
    if (!map[r.product_id]) map[r.product_id] = [];
    map[r.product_id].push(r.url);
  }
  return map;
}
