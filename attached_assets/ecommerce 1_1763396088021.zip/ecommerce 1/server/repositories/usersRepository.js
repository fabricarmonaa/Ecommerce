export async function findByUsername(db, username) {
  const [rows] = await db.execute(
    `SELECT id, username, password_hash FROM users WHERE username = ? LIMIT 1`,
    [username]
  );
  return rows[0] || null;
}

export async function createAdminIfNotExists(db, username, passwordHash) {
  const [rows] = await db.execute(`SELECT id FROM users WHERE username = ?`, [username]);
  if (rows.length) return rows[0].id;
  const [result] = await db.execute(
    `INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'admin')`,
    [username, passwordHash]
  );
  return result.insertId;
  
}
