import { findAll, findById } from '../repositories/productsRepository.js';

export async function listProducts(db, params) {
  return findAll(db, params);
}

export async function getProduct(db, id) {
  return findById(db, id);
}
