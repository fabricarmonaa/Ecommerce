// server/utils/cookies.js
export function parseCookies(header = '') {
  const out = {};
  header.split(';').forEach(part => {
    const [k, ...rest] = part.trim().split('=');
    if (!k) return;
    out[k] = decodeURIComponent((rest.join('=') || '').trim());
  });
  return out;
}

export function setCookie(res, name, value, {
  httpOnly = true,
  sameSite = 'Lax',
  secure = false,
  maxAgeSec,
  path = '/'
} = {}) {
  const parts = [`${name}=${encodeURIComponent(value)}`, `Path=${path}`];
  if (httpOnly) parts.push('HttpOnly');
  if (secure) parts.push('Secure');
  if (sameSite) parts.push(`SameSite=${sameSite}`);
  if (typeof maxAgeSec === 'number') parts.push(`Max-Age=${maxAgeSec}`);

  const cookieStr = parts.join('; ');

  const existing = res.getHeader('Set-Cookie');
  const arr = existing
    ? (Array.isArray(existing) ? existing : [existing])
    : [];
  arr.push(cookieStr);
  res.setHeader('Set-Cookie', arr);
}
