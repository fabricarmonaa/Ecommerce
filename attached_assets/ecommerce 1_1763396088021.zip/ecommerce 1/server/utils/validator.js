export function validateProductInput(body = {}, { requireAll = false } = {}) {
  const data = {};
  const errs = [];

  const fields = ['name','description','price','image_url','stock','category'];
  fields.forEach(f => {
    if (requireAll && (body[f] === undefined || body[f] === null || body[f] === '')) {
      errs.push(`Campo requerido: ${f}`);
    }
  });

  if (body.name !== undefined) data.name = String(body.name).slice(0, 255);
  if (body.description !== undefined) data.description = String(body.description).slice(0, 5000);
  if (body.price !== undefined) {
    const p = Number(body.price);
    if (Number.isNaN(p) || p < 0) errs.push('price inválido');
    else data.price = p;
  }
  if (body.image_url !== undefined) data.image_url = String(body.image_url).slice(0, 500);
  if (body.stock !== undefined) {
    const st = Number(body.stock);
    if (!Number.isInteger(st) || st < 0) errs.push('stock inválido');
    else data.stock = st;
  }
  if (body.category !== undefined) data.category = String(body.category).slice(0, 100);

  if (errs.length) return { valid: false, error: errs.join(', ') };
  return { valid: true, data };
}
