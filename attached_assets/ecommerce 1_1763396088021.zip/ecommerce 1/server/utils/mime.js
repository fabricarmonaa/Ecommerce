export function getContentType(filePath) {
  const ext = filePath.split('.').pop().toLowerCase();
  const map = {
    html: 'text/html; charset=utf-8',
    css: 'text/css; charset=utf-8',
    js: 'application/javascript; charset=utf-8',
    png: 'image/png',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    svg: 'image/svg+xml',
    json: 'application/json; charset=utf-8',
    txt: 'text/plain; charset=utf-8'
  };
  return map[ext] ?? 'application/octet-stream';
}
